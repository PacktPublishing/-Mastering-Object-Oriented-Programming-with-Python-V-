'''
Created on May 22, 2019
@author: Burkhard A. Meier
'''





import logging

help(logging)                # prints out all
# print(logging.__doc__)       # prints out only the module docstring
























