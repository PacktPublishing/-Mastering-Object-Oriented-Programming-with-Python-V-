'''
Created on May 22, 2019
@author: Burkhard A. Meier
'''





class PythonClass(object):
    def __init__(self, name):      
        self.name = name                            

    def get_name(self):
        return self.name                

if __name__== '__main__': 
#     inst = PythonClass()
    help(PythonClass)

    









    
    
    
    