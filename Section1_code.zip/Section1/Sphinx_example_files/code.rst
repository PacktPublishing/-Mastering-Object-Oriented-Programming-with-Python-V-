Code Docstrings
===============

.. automodule:: Section1.Section1_Video_5_2_docstrings_added	 
	:members:

.. automodule:: Section1.Section1_Video_5_4_docstrings_other	 
	:members:

