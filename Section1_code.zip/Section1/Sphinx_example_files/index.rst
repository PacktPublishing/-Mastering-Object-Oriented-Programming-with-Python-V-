.. Mastering OOP with Python documentation master file, created by
   sphinx-quickstart on Wed May 22 19:02:27 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Mastering OOP with Python's documentation!
=====================================================
In this video course...

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   code


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
