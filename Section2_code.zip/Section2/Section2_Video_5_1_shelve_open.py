'''
Created on Jun 18, 2019
@author: Burkhard A. Meier
'''






import shelve
        

db_shelf = shelve.open('PythonClassShelve.db')
print(db_shelf)














