'''
Created on June 17, 2019
@author: Burkhard A. Meier
'''





import sqlite3
conn = sqlite3.connect('PythonClass.db')        # creates the db if it does not exist  
conn.close()                                    # close the connection                                  






























