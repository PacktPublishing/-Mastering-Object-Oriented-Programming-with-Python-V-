'''
Created on May 12, 2019
@author: Burkhard A. Meier
'''





#--------------------------------------------------
# Create class 'blue print'
#--------------------------------------------------

class PythonClass(object):          # all classes in Python inherit from the 'object' class
    
    def __init__(self):             
        pass
                     
#--------------------------------------------------
# Create instance(s) of class
#--------------------------------------------------

first_instance = PythonClass()

























