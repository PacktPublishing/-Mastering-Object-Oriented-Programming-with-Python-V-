'''
Created on Jun 20, 2019
@author: Burkhard A. Meier
'''








from Section3.Section3_Video_4_3_all_API import *

bob = PythonClass("Bob")
print(bob.get_name_and_items())






























