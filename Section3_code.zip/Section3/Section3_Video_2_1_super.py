'''
Created on Jun 19, 2019
@author: Burkhard A. Meier
'''







class PythonSuperClass():
    def __init__(self):
        pass


class PythonClass(PythonSuperClass):
    def __init__(self):
        super().__init__()

        
PythonClass() 

















