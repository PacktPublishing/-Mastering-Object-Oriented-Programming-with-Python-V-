'''
Created on Jun 20, 2019
@author: Burkhard A. Meier
'''








from Section3.Section3_Video_4_2_all import PythonClass
from Section3.Section3_Video_4_2_all import PythonSuperClass


bob = PythonClass("Bob")
print(bob.get_name_and_items())

spacey = PythonSuperClass("Space", 1)
print(spacey.get_name_and_items())





























