'''
Created on Jun 19, 2019
@author: Burkhard A. Meier
'''








class PythonClassNoInit():
    pass
    
    
class PythonClass():   
    def __init__(self):
        pass
    
    
    
print(PythonClassNoInit()) 
print(PythonClass())


























